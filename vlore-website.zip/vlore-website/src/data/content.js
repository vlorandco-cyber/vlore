// All copy lives here, sourced from the Vlore Messaging System (Ascent V2).
// Edit text in one place — components stay focused on layout and motion.

export const hero = {
  tag: "VLORE — A Growth Partner for Ambitious Brands",
  headline: "Designed to Be Inevitable.",
  cta: "Begin Growing Together",
};

export const problem = {
  eyebrow: "The Problem",
  headline: "Growth fails from fragmentation.",
  body: [
    "A website built by one team. Advertising run by another. A funnel nobody has opened since launch. A list of past customers nobody has spoken to since they bought.",
    "Each piece might be good. None of them are talking to each other — and that gap is where growth quietly leaks out.",
  ],
};

// The five connected systems behind Vlore's work.
export const systems = [
  {
    id: "bedrock",
    number: "01",
    name: "Bedrock",
    title: "Foundation",
    caption: "Everything that grows needs something to grow from.",
    services: ["Website Development", "Shopify Development"],
    visual: "bedrock",
  },
  {
    id: "beacon",
    number: "02",
    name: "Beacon",
    title: "Visibility",
    caption: "Built well and unseen is still unseen.",
    services: ["Google Ads", "Paid Advertising"],
    visual: "beacon",
  },
  {
    id: "confluence",
    number: "03",
    name: "Confluence",
    title: "Conversion",
    caption: "Attention is easy to win and easy to waste. The difference is the path.",
    services: ["Landing Pages", "Funnels", "Conversion Optimisation"],
    visual: "confluence",
  },
  {
    id: "lattice",
    number: "04",
    name: "Lattice",
    title: "Relationship",
    caption: "A sale isn't an ending. It's the first thing two people have agreed on.",
    services: ["Email Marketing", "Customer Retention"],
    visual: "lattice",
  },
  {
    id: "ecosystem",
    number: "05",
    name: "Ecosystem",
    title: "Scale",
    caption: "None of this works in isolation. That's the entire point.",
    services: ["Growth Systems", "Ongoing Partnership"],
    visual: "ecosystem",
  },
];

export const confluenceSignature = {
  eyebrow: "Confluence — A Closer Look",
  headline: "Attention is easy to win and easy to waste.",
  subheadline: "The difference is the path.",
  body: "Every visitor that arrives is a small amount of light. Without a deliberate path, most of it scatters and disappears. With one, it converges — and becomes something durable.",
  wasted: "Lost along the way",
  converted: "Guided into value",
};

export const ecosystemView = {
  eyebrow: "The Ecosystem View",
  headline: "Five Systems. One Living Whole.",
  body: "This is what it looks like when a foundation, a signal, a path, a relationship, and a system for compounding all of it stop operating separately — and start operating as one.",
};

export const whyVlore = {
  eyebrow: "Why This Works Differently",
  items: [
    {
      title: "One team, one connected system",
      body: "Your website, your advertising, your funnels, and your retention all influence each other. We design them together — because that's the only way any of them actually compounds.",
    },
    {
      title: "We stay involved",
      body: "A strategy handed off and left alone starts decaying the day it launches. We remain part of the system — tuning it as your market, your customers, and your business change.",
    },
    {
      title: "We work with fewer brands, on purpose",
      body: "The attention a serious partnership requires doesn't scale infinitely, so we don't try to make it. Better work for fewer companies than adequate work for many.",
    },
    {
      title: "Every claim, attached to a number",
      body: "We don't ask you to take our word for the system working. Every system we build is measured, and every result we show you is one we can stand behind.",
    },
  ],
};

export const packages = [
  {
    name: "Foundation",
    price: "$1,500 – $2,000",
    unit: "CAD",
    description:
      "For brands establishing the base everything else will be built on.",
    features: [
      "Website or Shopify build",
      "Brand-aligned design system",
      "Core technical foundation",
      "Mobile-first, conversion-ready structure",
    ],
  },
  {
    name: "Growth",
    price: "$3,000 – $4,500",
    unit: "CAD",
    description:
      "For brands ready to be seen — and to start converting that attention.",
    features: [
      "Everything in Foundation",
      "Paid advertising setup (Google & Paid Media)",
      "Landing pages & funnel design",
      "Conversion optimisation, first pass",
    ],
    featured: true,
  },
  {
    name: "Scale",
    price: "$4,500 – $7,000",
    unit: "CAD",
    description:
      "For brands ready to operate as one connected growth system.",
    features: [
      "Everything in Growth",
      "Email marketing & retention systems",
      "Full five-system build, integrated",
      "Reporting across the whole ecosystem",
    ],
  },
];

export const ongoing = {
  name: "Ongoing Growth Partnership",
  price: "$1,000 – $3,000",
  unit: "CAD / month",
  description:
    "The system, tended continuously. Ongoing management, optimisation, and growth across every active system — for brands ready to keep compounding.",
};

export const epilogue = {
  intimacy: "From here, it isn't a presentation. It's a partnership.",
  confidenceHeadline: "This Is What Happens Next.",
  confidenceBody:
    "We take on a small number of brands at a time — because a system like this only works when it's tended, not templated. If that's the kind of growth you're building toward, this is where we start.",
  cta: "Begin Growing Together",
  formNote: "Tell us a little about where you are, and where you're headed.",
};

export const nav = {
  wordmark: "VLORE",
  links: [
    { label: "The Problem", href: "#problem" },
    { label: "Bedrock", href: "#bedrock" },
    { label: "Beacon", href: "#beacon" },
    { label: "Confluence", href: "#confluence" },
    { label: "Lattice", href: "#lattice" },
    { label: "Ecosystem", href: "#ecosystem" },
    { label: "Why Vlore", href: "#why-vlore" },
    { label: "Partnerships", href: "#packages" },
    { label: "Begin", href: "#contact" },
  ],
};
