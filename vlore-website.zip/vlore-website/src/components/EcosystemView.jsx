import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { ecosystemView as copy, systems } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

const GOLD = "#C9A05A";
const SPARK = "#FFE3B8";
const STONE = "#8B847A";

// Pentagon layout around a central point, in viewBox 0 0 500 500.
const CENTER = { x: 250, y: 250 };
const RADIUS = 180;

function pentagonPoint(i) {
  const angle = (-90 + i * 72) * (Math.PI / 180);
  return {
    x: CENTER.x + RADIUS * Math.cos(angle),
    y: CENTER.y + RADIUS * Math.sin(angle),
  };
}

// Label placement offsets so text sits outside the network, on the
// correct side of each node.
const labelOffsets = [
  { dx: 0, dy: -26, anchor: "middle" },
  { dx: 28, dy: 6, anchor: "start" },
  { dx: 16, dy: 30, anchor: "start" },
  { dx: -16, dy: 30, anchor: "end" },
  { dx: -28, dy: 6, anchor: "end" },
];

export default function EcosystemView() {
  const sectionRef = useRef(null);
  const headRef = useRef(null);

  const nodes = systems.map((s, i) => ({ ...pentagonPoint(i), system: s }));

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headRef.current.children,
        { opacity: 0, y: 16 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.12,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 70%" },
        }
      );

      const svg = sectionRef.current.querySelector("svg");

      gsap.fromTo(
        svg.querySelectorAll(".ring"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 1,
          stagger: 0.15,
          ease: "power2.inOut",
          scrollTrigger: { trigger: sectionRef.current, start: "top 60%" },
        }
      );
      gsap.fromTo(
        svg.querySelectorAll(".spoke"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 0.9,
          stagger: 0.1,
          delay: 0.7,
          ease: "power2.inOut",
          scrollTrigger: { trigger: sectionRef.current, start: "top 60%" },
        }
      );
      gsap.fromTo(
        svg.querySelectorAll(".net-node"),
        { opacity: 0, scale: 0 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.5,
          stagger: 0.1,
          transformOrigin: "center",
          scrollTrigger: { trigger: sectionRef.current, start: "top 60%" },
        }
      );
      gsap.fromTo(
        svg.querySelectorAll(".net-label"),
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          delay: 1.3,
          scrollTrigger: { trigger: sectionRef.current, start: "top 60%" },
        }
      );
      gsap.to(svg.querySelectorAll(".net-node, .net-center"), {
        scale: 1.08,
        duration: 3,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut",
        transformOrigin: "center",
        delay: 2,
        stagger: { each: 0.15, from: "center" },
        scrollTrigger: { trigger: sectionRef.current, start: "top 60%" },
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      id="ecosystem-view"
      ref={sectionRef}
      className="relative py-32 sm:py-40 px-6 sm:px-10 lg:px-24"
    >
      <div ref={headRef} className="max-w-3xl mx-auto text-center mb-16">
        <p className="font-mono text-[11px] tracking-widest2 text-gold uppercase mb-5">
          {copy.eyebrow}
        </p>
        <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ivory mb-6">
          {copy.headline}
        </h2>
        <p className="font-sans text-base sm:text-lg text-stone leading-relaxed max-w-2xl mx-auto">
          {copy.body}
        </p>
      </div>

      <div className="max-w-2xl mx-auto aspect-square">
        <svg viewBox="0 0 500 500" className="w-full h-full" aria-hidden="true">
          <defs>
            <filter id="blur-ecoview" x="-100%" y="-100%" width="300%" height="300%">
              <feGaussianBlur stdDeviation="14" />
            </filter>
          </defs>

          {nodes.map((n, i) => {
            const next = nodes[(i + 1) % nodes.length];
            return (
              <line
                key={`ring-${i}`}
                className="ring"
                x1={n.x}
                y1={n.y}
                x2={next.x}
                y2={next.y}
                stroke={STONE}
                strokeWidth="1"
                pathLength="1"
                strokeDasharray="1 1"
                opacity="0.35"
              />
            );
          })}

          {nodes.map((n, i) => (
            <line
              key={`spoke-${i}`}
              className="spoke"
              x1={CENTER.x}
              y1={CENTER.y}
              x2={n.x}
              y2={n.y}
              stroke={GOLD}
              strokeWidth="1"
              pathLength="1"
              strokeDasharray="1 1"
              opacity="0.55"
            />
          ))}

          <circle className="net-center" cx={CENTER.x} cy={CENTER.y} r="60" fill={SPARK} opacity="0.12" filter="url(#blur-ecoview)" />
          <circle className="net-center" cx={CENTER.x} cy={CENTER.y} r="9" fill={GOLD} />

          {nodes.map((n, i) => (
            <g key={`node-${i}`}>
              <circle className="net-node" cx={n.x} cy={n.y} r="6" fill={GOLD} />
              <text
                className="net-label"
                x={n.x + labelOffsets[i].dx}
                y={n.y + labelOffsets[i].dy}
                textAnchor={labelOffsets[i].anchor}
                fill="#F3EEE4"
                fontFamily="Cormorant Garamond, serif"
                fontSize="20"
              >
                {n.system.name}
              </text>
            </g>
          ))}
        </svg>
      </div>
    </section>
  );
}
