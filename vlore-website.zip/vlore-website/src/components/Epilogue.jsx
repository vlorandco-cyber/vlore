import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import Spark from "./Spark";
import { epilogue } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

export default function Epilogue() {
  const sectionRef = useRef(null);
  const sparkLeftRef = useRef(null);
  const sparkRightRef = useRef(null);
  const intimacyRef = useRef(null);
  const confidenceRef = useRef(null);
  const formRef = useRef(null);

  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        sparkLeftRef.current,
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1.6,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 65%" },
        }
      );
      gsap.fromTo(
        sparkRightRef.current,
        { x: 60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1.6,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 65%" },
        }
      );
      gsap.fromTo(
        intimacyRef.current,
        { opacity: 0, y: 16 },
        {
          opacity: 1,
          y: 0,
          duration: 1.2,
          delay: 0.6,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 65%" },
        }
      );
      gsap.fromTo(
        confidenceRef.current.children,
        { opacity: 0, y: 16 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.12,
          delay: 1.4,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 65%" },
        }
      );
      gsap.fromTo(
        formRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          delay: 1.7,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 65%" },
        }
      );
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // MVP placeholder: no backend wired up yet.
    // To make this functional, send `form` to an email service,
    // form-handling endpoint (e.g. Formspree), or your own API route.
    setSubmitted(true);
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-32 sm:py-40 px-6 sm:px-10 lg:px-24 overflow-hidden"
    >
      <div
        className="absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(circle at 50% 30%, rgba(201,160,90,0.06), transparent 60%), #0F0E0C",
        }}
      />

      <div className="max-w-3xl mx-auto text-center">
        {/* Two lights settling beside each other */}
        <div className="flex items-center justify-center gap-6 mb-12">
          <div ref={sparkLeftRef}>
            <Spark size={16} glow={90} />
          </div>
          <div ref={sparkRightRef}>
            <Spark size={16} glow={90} color="#C9A05A" />
          </div>
        </div>

        <p
          ref={intimacyRef}
          className="font-serif italic text-2xl sm:text-3xl text-ivory/90 mb-20"
        >
          {epilogue.intimacy}
        </p>

        <div ref={confidenceRef}>
          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ivory mb-6">
            {epilogue.confidenceHeadline}
          </h2>
          <p className="font-sans text-base sm:text-lg text-stone leading-relaxed max-w-xl mx-auto mb-12">
            {epilogue.confidenceBody}
          </p>
        </div>

        <div ref={formRef} className="max-w-md mx-auto text-left">
          {submitted ? (
            <div className="border border-gold/30 rounded-sm p-8 text-center">
              <Spark size={12} glow={60} className="mx-auto mb-5" />
              <p className="font-serif text-xl text-ivory mb-2">Thank you.</p>
              <p className="font-sans text-sm text-stone">
                We've received your note — we'll be in touch shortly.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <p className="font-sans text-sm text-stone text-center mb-2">
                {epilogue.formNote}
              </p>
              <div>
                <label htmlFor="name" className="sr-only">
                  Name
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  value={form.name}
                  onChange={handleChange}
                  placeholder="Name"
                  className="w-full bg-transparent border-b border-ivory/20 focus:border-gold py-3 font-sans text-ivory placeholder:text-stone/60 outline-none transition-colors duration-300"
                />
              </div>
              <div>
                <label htmlFor="email" className="sr-only">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={handleChange}
                  placeholder="Email"
                  className="w-full bg-transparent border-b border-ivory/20 focus:border-gold py-3 font-sans text-ivory placeholder:text-stone/60 outline-none transition-colors duration-300"
                />
              </div>
              <div>
                <label htmlFor="message" className="sr-only">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows="3"
                  value={form.message}
                  onChange={handleChange}
                  placeholder="Tell us about your brand"
                  className="w-full bg-transparent border-b border-ivory/20 focus:border-gold py-3 font-sans text-ivory placeholder:text-stone/60 outline-none resize-none transition-colors duration-300"
                />
              </div>
              <button
                type="submit"
                className="w-full font-sans text-sm tracking-widest text-ivory border border-gold/40 rounded-full px-8 py-4 hover:border-gold hover:shadow-glowSm transition-all duration-500 mt-4"
              >
                {epilogue.cta}
              </button>
            </form>
          )}
        </div>

        <footer className="mt-24 flex items-center justify-center gap-3 text-stone/60">
          <Spark size={8} glow={24} animate={false} />
          <span className="font-mono text-[11px] tracking-widest2 uppercase">
            Vlore — © {new Date().getFullYear()}
          </span>
        </footer>
      </div>
    </section>
  );
}
