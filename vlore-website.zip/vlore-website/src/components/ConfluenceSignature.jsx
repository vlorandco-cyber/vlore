import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { confluenceSignature as copy } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

const GOLD = "#C9A05A";
const SPARK = "#FFE3B8";
const STONE = "#8B847A";

export default function ConfluenceSignature() {
  const sectionRef = useRef(null);
  const pinRef = useRef(null);
  const counterRef = useRef(null);
  const wastedRef = useRef(null);
  const convertedRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const streams = pinRef.current.querySelectorAll(".stream");
      const leak = pinRef.current.querySelector(".leak");
      const leakDots = pinRef.current.querySelectorAll(".leak-dot");
      const pool = pinRef.current.querySelector(".pool");
      const poolGlow = pinRef.current.querySelector(".pool-glow");
      const orbs = pinRef.current.querySelectorAll(".orb");

      gsap.set(streams, { strokeDashoffset: 1 });
      gsap.set(leak, { strokeDashoffset: 1, opacity: 0.4 });
      gsap.set(leakDots, { opacity: 0 });
      gsap.set(pool, { scale: 0.4, transformOrigin: "center" });
      gsap.set(poolGlow, { scale: 0.4, opacity: 0.15, transformOrigin: "center" });
      gsap.set(orbs, { opacity: 0, scale: 0, transformOrigin: "center" });
      gsap.set(wastedRef.current, { opacity: 0 });
      gsap.set(convertedRef.current, { opacity: 0 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "bottom bottom",
          scrub: 1,
          pin: pinRef.current,
          onUpdate: (self) => {
            const pct = Math.round(self.progress * 86);
            if (counterRef.current) counterRef.current.textContent = `${pct}%`;
          },
        },
        defaults: { ease: "none" },
      });

      tl.to(streams, { strokeDashoffset: 0, duration: 1 }, 0)
        .to(leak, { strokeDashoffset: 0, duration: 0.6 }, 0)
        .to(wastedRef.current, { opacity: 1, duration: 0.2 }, 0.2)
        .to(leakDots, { opacity: 0.5, scale: 1, stagger: 0.05, duration: 0.3 }, 0.3)
        .to(leakDots, { opacity: 0, duration: 0.3 }, 0.65)
        .to(pool, { scale: 1, duration: 0.8 }, 0.3)
        .to(poolGlow, { scale: 1.1, opacity: 0.3, duration: 0.8 }, 0.3)
        .to(convertedRef.current, { opacity: 1, duration: 0.2 }, 0.45)
        .to(orbs, { opacity: 1, scale: 1, stagger: 0.08, duration: 0.3 }, 0.55);
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Three converging streams to the pool, one leak that fades away.
  const streamPaths = [
    "M40,0 C90,160 160,340 200,560",
    "M170,0 C175,200 190,400 200,560",
    "M380,0 C330,180 250,380 200,560",
  ];
  const leakPath = "M280,0 C340,80 390,150 390,240";
  const leakDots = [
    { x: 320, y: 60 },
    { x: 365, y: 130 },
    { x: 385, y: 210 },
  ];
  const orbPositions = [
    { x: 188, y: 545, r: 3 },
    { x: 213, y: 548, r: 2.5 },
    { x: 200, y: 535, r: 2 },
  ];

  return (
    <section ref={sectionRef} className="relative" style={{ height: "240vh" }}>
      <div
        ref={pinRef}
        className="h-screen w-full flex items-center px-6 sm:px-10 lg:px-24 overflow-hidden"
      >
        <div className="relative max-w-6xl mx-auto grid lg:grid-cols-2 gap-12 lg:gap-20 items-center w-full">
          <div className="order-2 lg:order-1">
            <p className="font-mono text-[11px] tracking-widest2 text-gold uppercase mb-5">
              {copy.eyebrow}
            </p>
            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ivory leading-tight mb-2">
              {copy.headline}
            </h2>
            <p className="font-serif italic text-2xl sm:text-3xl text-gold mb-8">
              {copy.subheadline}
            </p>
            <p className="font-sans text-base sm:text-lg text-stone leading-relaxed max-w-md mb-10">
              {copy.body}
            </p>

            <div className="flex items-center gap-4 font-mono text-xs tracking-widest uppercase">
              <span ref={wastedRef} className="text-stone">
                {copy.wasted}
              </span>
              <span className="text-stone/30">/</span>
              <span ref={convertedRef} className="text-gold flex items-center gap-2">
                {copy.converted}
                <span ref={counterRef} className="text-ivory">0%</span>
              </span>
            </div>
          </div>

          <div className="order-1 lg:order-2 aspect-[2/3] w-full max-w-sm mx-auto">
            <svg viewBox="0 0 400 600" className="w-full h-full" aria-hidden="true">
              <defs>
                <filter id="blur-confsig" x="-100%" y="-100%" width="300%" height="300%">
                  <feGaussianBlur stdDeviation="10" />
                </filter>
              </defs>

              {streamPaths.map((d, i) => (
                <path
                  key={i}
                  className="stream"
                  d={d}
                  fill="none"
                  stroke={GOLD}
                  strokeWidth="1.5"
                  pathLength="1"
                  strokeDasharray="1 1"
                  opacity={0.85 - i * 0.12}
                />
              ))}

              <path
                className="leak"
                d={leakPath}
                fill="none"
                stroke={STONE}
                strokeWidth="1"
                pathLength="1"
                strokeDasharray="1 1"
              />
              {leakDots.map((p, i) => (
                <circle key={i} className="leak-dot" cx={p.x} cy={p.y} r="2.5" fill={STONE} />
              ))}

              <circle className="pool-glow" cx="200" cy="555" r="50" fill={SPARK} filter="url(#blur-confsig)" />
              <circle className="pool" cx="200" cy="555" r="12" fill={GOLD} />

              {orbPositions.map((o, i) => (
                <circle key={i} className="orb" cx={o.x} cy={o.y} r={o.r} fill={SPARK} />
              ))}
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}
