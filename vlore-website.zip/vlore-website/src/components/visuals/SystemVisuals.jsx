import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const GOLD = "#C9A05A";
const SPARK = "#FFE3B8";
const STONE = "#8B847A";

/* Shared glow-point: a soft blurred halo behind a sharp core circle. */
function GlowPoint({ cx, cy, r = 6, blurId, className = "" }) {
  return (
    <g className={className}>
      <circle cx={cx} cy={cy} r={r * 3} fill={SPARK} opacity="0.18" filter={`url(#${blurId})`} />
      <circle cx={cx} cy={cy} r={r} fill={GOLD} />
    </g>
  );
}

function BlurDefs({ id }) {
  return (
    <defs>
      <filter id={id} x="-100%" y="-100%" width="300%" height="300%">
        <feGaussianBlur stdDeviation="6" />
      </filter>
    </defs>
  );
}

/* ---------- 01 Bedrock — foundation veins ---------- */
export function BedrockVisual() {
  const ref = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ref.current.querySelectorAll(".vein"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 1.8,
          stagger: 0.3,
          ease: "power2.inOut",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        ref.current.querySelector(".platform"),
        { opacity: 0 },
        {
          opacity: 0.22,
          duration: 1.4,
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        ref.current.querySelectorAll(".vein-end"),
        { opacity: 0, scale: 0 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.6,
          stagger: 0.3,
          delay: 1.2,
          transformOrigin: "center",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <svg ref={ref} viewBox="0 0 400 400" className="w-full h-full">
      <BlurDefs id="blur-bedrock" />
      <rect
        className="platform"
        x="60"
        y="230"
        width="280"
        height="130"
        fill="none"
        stroke={STONE}
        strokeWidth="1"
        opacity="0"
      />
      <path
        className="vein"
        d="M90,360 L160,280 L140,200 L235,165 L210,70"
        fill="none"
        stroke={GOLD}
        strokeWidth="1.5"
        pathLength="1"
        strokeDasharray="1 1"
        opacity="0.9"
      />
      <path
        className="vein"
        d="M340,360 L255,290 L300,205 L235,135"
        fill="none"
        stroke={GOLD}
        strokeWidth="1.5"
        pathLength="1"
        strokeDasharray="1 1"
        opacity="0.75"
      />
      <path
        className="vein"
        d="M70,250 L185,245 L205,330"
        fill="none"
        stroke={GOLD}
        strokeWidth="1.5"
        pathLength="1"
        strokeDasharray="1 1"
        opacity="0.6"
      />
      <g className="vein-end">
        <GlowPoint cx="210" cy="70" r="3" blurId="blur-bedrock" />
      </g>
      <g className="vein-end">
        <GlowPoint cx="235" cy="135" r="3" blurId="blur-bedrock" />
      </g>
    </svg>
  );
}

/* ---------- 02 Beacon — signal & reach ---------- */
export function BeaconVisual() {
  const ref = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ref.current.querySelectorAll(".ray"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 1.4,
          stagger: 0.18,
          ease: "power2.out",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        ref.current.querySelectorAll(".reached"),
        { opacity: 0.15, scale: 0.6 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.6,
          stagger: 0.18,
          delay: 0.6,
          transformOrigin: "center",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      ref.current.querySelectorAll(".ring").forEach((ring, i) => {
        gsap.fromTo(
          ring,
          { scale: 0.3, opacity: 0.5 },
          {
            scale: 1.6,
            opacity: 0,
            duration: 3,
            repeat: -1,
            delay: i * 1,
            ease: "power1.out",
            transformOrigin: "center",
            scrollTrigger: { trigger: ref.current, start: "top 75%" },
          }
        );
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  const rays = [
    { x: 60, y: 90 },
    { x: 340, y: 70 },
    { x: 360, y: 230 },
    { x: 70, y: 320 },
    { x: 300, y: 340 },
  ];

  return (
    <svg ref={ref} viewBox="0 0 400 400" className="w-full h-full">
      <BlurDefs id="blur-beacon" />
      {[1, 2, 3].map((n) => (
        <circle
          key={n}
          className="ring"
          cx="200"
          cy="200"
          r="40"
          fill="none"
          stroke={GOLD}
          strokeWidth="1"
        />
      ))}
      {rays.map((p, i) => (
        <line
          key={i}
          className="ray"
          x1="200"
          y1="200"
          x2={p.x}
          y2={p.y}
          stroke={GOLD}
          strokeWidth="1"
          pathLength="1"
          strokeDasharray="1 1"
          opacity="0.55"
        />
      ))}
      {rays.map((p, i) => (
        <circle key={i} className="reached" cx={p.x} cy={p.y} r="3" fill={STONE} opacity="0.8" />
      ))}
      <GlowPoint cx="200" cy="200" r="7" blurId="blur-beacon" />
    </svg>
  );
}

/* ---------- 03 Confluence — converging paths (preview) ---------- */
export function ConfluenceVisual() {
  const ref = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ref.current.querySelectorAll(".stream"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 1.8,
          stagger: 0.2,
          ease: "power2.inOut",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        ref.current.querySelector(".leak"),
        { strokeDashoffset: 1, opacity: 0 },
        {
          strokeDashoffset: 0,
          opacity: 0.35,
          duration: 1.4,
          ease: "power1.inOut",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        ref.current.querySelector(".pool"),
        { scale: 0.3, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 1,
          delay: 1.2,
          transformOrigin: "center",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <svg ref={ref} viewBox="0 0 400 400" className="w-full h-full">
      <BlurDefs id="blur-confluence" />
      <path
        className="stream"
        d="M50,20 Q120,200 200,340"
        fill="none"
        stroke={GOLD}
        strokeWidth="1.5"
        pathLength="1"
        strokeDasharray="1 1"
        opacity="0.85"
      />
      <path
        className="stream"
        d="M170,20 Q185,190 200,340"
        fill="none"
        stroke={GOLD}
        strokeWidth="1.5"
        pathLength="1"
        strokeDasharray="1 1"
        opacity="0.7"
      />
      <path
        className="stream"
        d="M350,20 Q280,200 200,340"
        fill="none"
        stroke={GOLD}
        strokeWidth="1.5"
        pathLength="1"
        strokeDasharray="1 1"
        opacity="0.55"
      />
      <path
        className="leak"
        d="M260,20 Q230,90 130,140"
        fill="none"
        stroke={STONE}
        strokeWidth="1"
        pathLength="1"
        strokeDasharray="1 1"
      />
      <g className="pool">
        <GlowPoint cx="200" cy="340" r="7" blurId="blur-confluence" />
      </g>
    </svg>
  );
}

/* ---------- 04 Lattice — connected network ---------- */
const latticeNodes = {
  hub: { x: 220, y: 170 },
  a: { x: 90, y: 90 },
  b: { x: 320, y: 70 },
  c: { x: 350, y: 250 },
  d: { x: 190, y: 330 },
  e: { x: 70, y: 270 },
};

export function LatticeVisual() {
  const ref = useRef(null);
  const nodes = latticeNodes;

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ref.current.querySelectorAll(".link"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 1,
          stagger: 0.15,
          ease: "power2.inOut",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        ref.current.querySelectorAll(".lnode"),
        { opacity: 0, scale: 0 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.5,
          stagger: 0.12,
          transformOrigin: "center",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );

      const pulse = ref.current.querySelector(".pulse");
      gsap.set(pulse, { attr: { cx: nodes.hub.x, cy: nodes.hub.y } });
      gsap
        .timeline({
          repeat: -1,
          repeatDelay: 1.5,
          delay: 1.4,
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        })
        .to(pulse, { opacity: 1, duration: 0.2 })
        .to(pulse, {
          attr: { cx: nodes.c.x, cy: nodes.c.y },
          duration: 1,
          ease: "power1.inOut",
        })
        .to(pulse, { opacity: 0, duration: 0.3 })
        .set(pulse, { attr: { cx: nodes.hub.x, cy: nodes.hub.y } });
    }, ref);
    return () => ctx.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const links = [
    [nodes.hub, nodes.a],
    [nodes.hub, nodes.b],
    [nodes.hub, nodes.c],
    [nodes.hub, nodes.d],
    [nodes.hub, nodes.e],
    [nodes.a, nodes.e],
  ];

  return (
    <svg ref={ref} viewBox="0 0 400 400" className="w-full h-full">
      <BlurDefs id="blur-lattice" />
      {links.map(([p1, p2], i) => (
        <line
          key={i}
          className="link"
          x1={p1.x}
          y1={p1.y}
          x2={p2.x}
          y2={p2.y}
          stroke={GOLD}
          strokeWidth="1"
          pathLength="1"
          strokeDasharray="1 1"
          opacity="0.5"
        />
      ))}
      {Object.entries(nodes).map(([key, p]) => (
        <circle
          key={key}
          className="lnode"
          cx={p.x}
          cy={p.y}
          r={key === "hub" ? 6 : 4}
          fill={key === "hub" ? GOLD : STONE}
        />
      ))}
      <circle className="pulse" r="5" fill={SPARK} opacity="0" filter="url(#blur-lattice)" />
    </svg>
  );
}

/* ---------- 05 Ecosystem — the whole network (preview) ---------- */
export function EcosystemVisual() {
  const ref = useRef(null);

  const center = { x: 200, y: 200 };
  const outer = [
    { x: 200, y: 80 },
    { x: 314, y: 163 },
    { x: 271, y: 297 },
    { x: 130, y: 297 },
    { x: 86, y: 163 },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ref.current.querySelectorAll(".ring-link"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 1,
          stagger: 0.15,
          ease: "power2.inOut",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        ref.current.querySelectorAll(".spoke"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 0.9,
          stagger: 0.1,
          delay: 0.8,
          ease: "power2.inOut",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        ref.current.querySelectorAll(".enode"),
        { opacity: 0, scale: 0 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.5,
          stagger: 0.1,
          transformOrigin: "center",
          scrollTrigger: { trigger: ref.current, start: "top 75%" },
        }
      );
      gsap.to(ref.current.querySelector(".ecenter"), {
        scale: 1.15,
        duration: 2.6,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut",
        transformOrigin: "center",
        delay: 1.8,
        scrollTrigger: { trigger: ref.current, start: "top 75%" },
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <svg ref={ref} viewBox="0 0 400 400" className="w-full h-full">
      <BlurDefs id="blur-ecosystem" />
      {outer.map((p, i) => {
        const next = outer[(i + 1) % outer.length];
        return (
          <line
            key={`ring-${i}`}
            className="ring-link"
            x1={p.x}
            y1={p.y}
            x2={next.x}
            y2={next.y}
            stroke={STONE}
            strokeWidth="1"
            pathLength="1"
            strokeDasharray="1 1"
            opacity="0.4"
          />
        );
      })}
      {outer.map((p, i) => (
        <line
          key={`spoke-${i}`}
          className="spoke"
          x1={center.x}
          y1={center.y}
          x2={p.x}
          y2={p.y}
          stroke={GOLD}
          strokeWidth="1"
          pathLength="1"
          strokeDasharray="1 1"
          opacity="0.6"
        />
      ))}
      {outer.map((p, i) => (
        <circle key={`node-${i}`} className="enode" cx={p.x} cy={p.y} r="4" fill={STONE} />
      ))}
      <g className="ecenter enode">
        <GlowPoint cx={center.x} cy={center.y} r="7" blurId="blur-ecosystem" />
      </g>
    </svg>
  );
}

