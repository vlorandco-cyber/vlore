import {
  BedrockVisual,
  BeaconVisual,
  ConfluenceVisual,
  LatticeVisual,
  EcosystemVisual,
} from "./SystemVisuals";

export const systemVisuals = {
  bedrock: BedrockVisual,
  beacon: BeaconVisual,
  confluence: ConfluenceVisual,
  lattice: LatticeVisual,
  ecosystem: EcosystemVisual,
};
