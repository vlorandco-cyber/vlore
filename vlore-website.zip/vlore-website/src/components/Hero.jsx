import { useEffect, useRef } from "react";
import gsap from "gsap";
import Spark from "./Spark";
import { hero } from "../data/content";

export default function Hero() {
  const tagRef = useRef(null);
  const headlineRef = useRef(null);
  const ctaRef = useRef(null);
  const sparkRef = useRef(null);
  const scrollHintRef = useRef(null);

  useEffect(() => {
    const tl = gsap.timeline({ defaults: { ease: "power2.out" } });

    tl.fromTo(
      sparkRef.current,
      { opacity: 0, scale: 0.6 },
      { opacity: 1, scale: 1, duration: 1.6 }
    )
      .fromTo(
        tagRef.current,
        { opacity: 0, y: 12 },
        { opacity: 1, y: 0, duration: 1 },
        "-=0.6"
      )
      .fromTo(
        headlineRef.current,
        { opacity: 0, y: 18 },
        { opacity: 1, y: 0, duration: 1.2 },
        "-=0.3"
      )
      .fromTo(
        ctaRef.current,
        { opacity: 0, y: 10 },
        { opacity: 1, y: 0, duration: 0.9 },
        "-=0.5"
      )
      .fromTo(
        scrollHintRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 1 },
        "-=0.3"
      );

    return () => tl.kill();
  }, []);

  const scrollToProblem = () => {
    document.getElementById("problem")?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  // A handful of faint, distant points — the world beyond the Spark.
  const distantPoints = [
    { top: "22%", left: "18%", size: 2, delay: "0s" },
    { top: "30%", left: "82%", size: 1.5, delay: "1.2s" },
    { top: "68%", left: "12%", size: 1.5, delay: "2.1s" },
    { top: "78%", left: "76%", size: 2, delay: "0.6s" },
    { top: "15%", left: "58%", size: 1, delay: "2.8s" },
    { top: "85%", left: "48%", size: 1, delay: "1.7s" },
  ];

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden px-6 text-center"
    >
      {/* Ambient gradient */}
      <div
        className="absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(circle at 50% 45%, rgba(201,160,90,0.07), transparent 55%), #0F0E0C",
        }}
      />

      {/* Distant points */}
      {distantPoints.map((p, i) => (
        <span
          key={i}
          className="absolute rounded-full bg-ivory animate-breatheSlow"
          style={{
            top: p.top,
            left: p.left,
            width: p.size,
            height: p.size,
            opacity: 0.25,
            animationDelay: p.delay,
          }}
          aria-hidden="true"
        />
      ))}

      {/* The Spark */}
      <div ref={sparkRef} className="mb-10">
        <Spark size={20} glow={140} className="shadow-sparkGlow" />
      </div>

      <p
        ref={tagRef}
        className="font-mono text-[11px] sm:text-xs tracking-widest2 text-stone uppercase mb-6"
      >
        {hero.tag}
      </p>

      <h1
        ref={headlineRef}
        className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-ivory font-medium leading-[1.05] max-w-4xl"
      >
        {hero.headline}
      </h1>

      <button
        ref={ctaRef}
        onClick={scrollToContact}
        className="mt-12 font-sans text-sm tracking-widest text-ivory border border-gold/40 rounded-full px-8 py-3 hover:border-gold hover:shadow-glowSm transition-all duration-500"
      >
        {hero.cta}
      </button>

      {/* Scroll hint */}
      <button
        ref={scrollHintRef}
        onClick={scrollToProblem}
        aria-label="Scroll to explore"
        className="absolute bottom-10 flex flex-col items-center gap-3 text-stone hover:text-ivory transition-colors duration-500"
      >
        <span className="font-mono text-[10px] tracking-widest2 uppercase">
          Scroll
        </span>
        <span className="block w-px h-10 bg-gradient-to-b from-stone to-transparent animate-driftDown" />
      </button>
    </section>
  );
}
