import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { packages, ongoing } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

export default function Packages() {
  const sectionRef = useRef(null);
  const headRef = useRef(null);
  const cardsRef = useRef(null);
  const ongoingRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headRef.current,
        { opacity: 0, y: 16 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        cardsRef.current.children,
        { opacity: 0, y: 28 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          stagger: 0.15,
          ease: "power2.out",
          scrollTrigger: { trigger: cardsRef.current, start: "top 80%" },
        }
      );
      gsap.fromTo(
        ongoingRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power2.out",
          scrollTrigger: { trigger: ongoingRef.current, start: "top 85%" },
        }
      );
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="packages"
      ref={sectionRef}
      className="relative py-32 sm:py-40 px-6 sm:px-10 lg:px-24"
    >
      <div className="max-w-6xl mx-auto">
        <div ref={headRef} className="mb-16 max-w-2xl">
          <p className="font-mono text-[11px] tracking-widest2 text-gold uppercase mb-5">
            Growth Partnerships
          </p>
          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ivory">
            Ways to begin.
          </h2>
        </div>

        <div ref={cardsRef} className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {packages.map((pkg) => (
            <div
              key={pkg.name}
              className={`relative flex flex-col rounded-sm p-8 sm:p-10 transition-all duration-500 hover:shadow-cardGlow ${
                pkg.featured
                  ? "border border-gold/40 bg-obsidian2"
                  : "border border-ivory/10 bg-obsidian2/60"
              }`}
            >
              {pkg.featured && (
                <span className="absolute top-6 right-8 font-mono text-[10px] tracking-widest2 text-gold uppercase">
                  Most chosen
                </span>
              )}
              <h3 className="font-serif text-3xl text-ivory mb-2">{pkg.name}</h3>
              <p className="font-mono text-xl text-gold mb-1">
                {pkg.price}
                <span className="text-sm text-stone ml-2">{pkg.unit}</span>
              </p>
              <p className="font-sans text-sm text-stone leading-relaxed mb-8">
                {pkg.description}
              </p>
              <ul className="space-y-3 mb-10 flex-1">
                {pkg.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 font-sans text-sm text-ivory/80">
                    <span className="block w-1.5 h-1.5 rounded-full bg-gold mt-1.5 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={scrollToContact}
                className="font-sans text-sm tracking-wide text-ivory border border-ivory/20 rounded-full px-6 py-3 hover:border-gold hover:text-ivory hover:shadow-glowSm transition-all duration-500 text-left"
              >
                Begin with {pkg.name} →
              </button>
            </div>
          ))}
        </div>

        <div
          ref={ongoingRef}
          className="mt-8 rounded-sm border border-gold/30 bg-gradient-to-r from-obsidian2 to-obsidian p-8 sm:p-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6"
        >
          <div>
            <h3 className="font-serif text-2xl sm:text-3xl text-ivory mb-2">
              {ongoing.name}
            </h3>
            <p className="font-sans text-sm sm:text-base text-stone max-w-xl leading-relaxed">
              {ongoing.description}
            </p>
          </div>
          <div className="text-left sm:text-right shrink-0">
            <p className="font-mono text-2xl text-gold">
              {ongoing.price}
              <span className="text-sm text-stone ml-2">{ongoing.unit}</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
