import { useEffect, useState, useRef } from "react";
import Spark from "./Spark";
import { nav, systems } from "../data/content";

// The growth rail shows the five systems only — it's the "skip ahead"
// mechanism from the UX blueprint, condensed to what an MVP needs.
const railSections = systems.map((s) => ({ id: s.id, label: s.number }));

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(systems[0].id);
  const [scrolled, setScrolled] = useState(false);
  const sectionRefs = useRef({});

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: 0 }
    );

    systems.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) {
        observer.observe(el);
        sectionRefs.current[s.id] = el;
      }
    });

    return () => observer.disconnect();
  }, []);

  const handleNavClick = (href) => {
    setOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      {/* Wordmark */}
      <div
        className={`fixed top-0 left-0 z-40 flex items-center gap-3 px-6 sm:px-10 py-6 transition-colors duration-500 ${
          scrolled ? "backdrop-blur-sm" : ""
        }`}
      >
        <Spark size={10} glow={36} />
        <a
          href="#hero"
          onClick={(e) => {
            e.preventDefault();
            handleNavClick("#hero");
          }}
          className="font-sans text-xs tracking-widest2 text-ivory/80 hover:text-ivory transition-colors"
        >
          {nav.wordmark}
        </a>
      </div>

      {/* Menu toggle */}
      <button
        onClick={() => setOpen(true)}
        aria-label="Open menu"
        className="fixed top-0 right-0 z-40 flex items-center gap-2 px-6 sm:px-10 py-6 group"
      >
        <span className="font-sans text-xs tracking-widest2 text-ivory/60 group-hover:text-ivory/90 transition-colors hidden sm:inline">
          MENU
        </span>
        <Spark size={10} glow={36} animate />
      </button>

      {/* Growth rail — desktop only */}
      <div className="hidden lg:flex fixed right-8 top-1/2 -translate-y-1/2 z-30 flex-col items-center gap-5">
        {railSections.map((s) => (
          <button
            key={s.id}
            onClick={() => handleNavClick(`#${s.id}`)}
            aria-label={`Go to ${s.id}`}
            className="group relative flex items-center justify-center"
          >
            <span
              className={`block rounded-full transition-all duration-500 ${
                active === s.id
                  ? "w-2.5 h-2.5 bg-gold shadow-glowSm"
                  : "w-1.5 h-1.5 bg-stone/50 group-hover:bg-stone"
              }`}
            />
            <span className="absolute right-full mr-3 font-mono text-[10px] tracking-widest text-stone opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              {s.label}
            </span>
          </button>
        ))}
      </div>

      {/* Full-screen menu overlay */}
      <div
        className={`fixed inset-0 z-50 bg-obsidian/97 backdrop-blur-md transition-all duration-700 ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      >
        <button
          onClick={() => setOpen(false)}
          aria-label="Close menu"
          className="absolute top-6 right-6 sm:top-10 sm:right-10 font-sans text-xs tracking-widest2 text-ivory/60 hover:text-ivory transition-colors"
        >
          CLOSE
        </button>

        <nav className="h-full flex flex-col items-center justify-center gap-3 sm:gap-4">
          {nav.links.map((link, i) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                handleNavClick(link.href);
              }}
              className="font-serif text-3xl sm:text-5xl text-ivory/70 hover:text-ivory transition-colors duration-300"
              style={{ transitionDelay: `${i * 30}ms` }}
            >
              {link.label}
            </a>
          ))}
        </nav>
      </div>
    </>
  );
}
