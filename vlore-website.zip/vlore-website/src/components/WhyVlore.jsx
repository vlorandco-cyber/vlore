import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { whyVlore } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

export default function WhyVlore() {
  const sectionRef = useRef(null);
  const headRef = useRef(null);
  const gridRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headRef.current,
        { opacity: 0, y: 16 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 75%" },
        }
      );
      gsap.fromTo(
        gridRef.current.children,
        { opacity: 0, y: 24 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          stagger: 0.15,
          ease: "power2.out",
          scrollTrigger: { trigger: gridRef.current, start: "top 80%" },
        }
      );
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      id="why-vlore"
      ref={sectionRef}
      className="relative py-32 sm:py-40 px-6 sm:px-10 lg:px-24 bg-obsidian2"
    >
      <div className="max-w-6xl mx-auto">
        <h2
          ref={headRef}
          className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ivory mb-16 max-w-2xl"
        >
          {whyVlore.eyebrow}
        </h2>

        <div ref={gridRef} className="grid sm:grid-cols-2 gap-12 sm:gap-16">
          {whyVlore.items.map((item) => (
            <div key={item.title}>
              <span className="block w-2 h-2 rounded-full bg-gold shadow-glowSm mb-5" />
              <h3 className="font-serif text-2xl sm:text-3xl text-ivory mb-3">
                {item.title}
              </h3>
              <p className="font-sans text-sm sm:text-base text-stone leading-relaxed max-w-md">
                {item.body}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
