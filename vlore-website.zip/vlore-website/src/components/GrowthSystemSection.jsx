import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { systemVisuals } from "./visuals";

gsap.registerPlugin(ScrollTrigger);

export default function GrowthSystemSection({ system, index }) {
  const sectionRef = useRef(null);
  const textRef = useRef(null);
  const numberRef = useRef(null);

  const Visual = systemVisuals[system.visual];
  const reversed = index % 2 === 1;

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        textRef.current.children,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.12,
          ease: "power2.out",
          scrollTrigger: { trigger: sectionRef.current, start: "top 70%" },
        }
      );
      gsap.fromTo(
        numberRef.current,
        { opacity: 0 },
        {
          opacity: 0.08,
          duration: 1.4,
          scrollTrigger: { trigger: sectionRef.current, start: "top 75%" },
        }
      );
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      id={system.id}
      ref={sectionRef}
      className="relative py-28 sm:py-36 px-6 sm:px-10 lg:px-24 overflow-hidden"
    >
      {/* Giant faint system number */}
      <span
        ref={numberRef}
        className="pointer-events-none absolute -top-10 sm:-top-16 select-none font-serif text-ivory opacity-0"
        style={{
          fontSize: "clamp(8rem, 28vw, 22rem)",
          lineHeight: 1,
          [reversed ? "right" : "left"]: "-0.05em",
        }}
        aria-hidden="true"
      >
        {system.number}
      </span>

      <div
        className={`relative max-w-6xl mx-auto grid lg:grid-cols-2 gap-12 lg:gap-20 items-center ${
          reversed ? "lg:[&>*:first-child]:order-2" : ""
        }`}
      >
        <div ref={textRef}>
          <p className="font-mono text-[11px] tracking-widest2 text-gold uppercase mb-5">
            {system.number} — {system.title}
          </p>
          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ivory mb-5">
            {system.name}
          </h2>
          <p className="font-serif italic text-lg sm:text-xl text-stone leading-relaxed max-w-md mb-8">
            {system.caption}
          </p>
          <ul className="space-y-3">
            {system.services.map((s) => (
              <li key={s} className="flex items-center gap-3 font-sans text-sm sm:text-base text-ivory/80">
                <span className="block w-1.5 h-1.5 rounded-full bg-gold shadow-glowSm" />
                {s}
              </li>
            ))}
          </ul>
        </div>

        <div className="aspect-square w-full max-w-md mx-auto">
          <Visual />
        </div>
      </div>
    </section>
  );
}
