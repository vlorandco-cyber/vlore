/**
 * Spark — the recurring point of light.
 * Every glowing point across the site (hero, nav, epilogue) is this same
 * element at a different scale, in keeping with "the brand is one light,
 * seen at different distances."
 */
export default function Spark({
  size = 14,
  glow = 60,
  className = "",
  animate = true,
  color = "#FFE3B8",
}) {
  return (
    <span
      className={`pointer-events-none inline-block rounded-full ${
        animate ? "animate-breathe" : ""
      } ${className}`}
      style={{
        width: size,
        height: size,
        background: `radial-gradient(circle, ${color} 0%, #C9A05A 55%, rgba(201,160,90,0) 100%)`,
        boxShadow: `0 0 ${glow}px ${Math.max(glow / 3, 4)}px rgba(255,227,184,0.22)`,
      }}
      aria-hidden="true"
    />
  );
}
