import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { problem } from "../data/content";

gsap.registerPlugin(ScrollTrigger);

// Scattered, unconnected points and stray line fragments —
// the visual language of fragmentation, before the Lattice/Ecosystem
// sections show everything connected.
const nodes = [
  { x: 60, y: 60 },
  { x: 220, y: 40 },
  { x: 320, y: 160 },
  { x: 120, y: 220 },
  { x: 260, y: 280 },
  { x: 40, y: 320 },
];

const strays = [
  { x1: 60, y1: 60, x2: 130, y2: 95 },
  { x1: 220, y1: 40, x2: 175, y2: 90 },
  { x1: 320, y1: 160, x2: 270, y2: 130 },
  { x1: 120, y1: 220, x2: 175, y2: 250 },
  { x1: 260, y1: 280, x2: 200, y2: 305 },
];

export default function Problem() {
  const sectionRef = useRef(null);
  const svgRef = useRef(null);
  const textRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        textRef.current.children,
        { opacity: 0, y: 16 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.15,
          ease: "power2.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 70%",
          },
        }
      );

      gsap.fromTo(
        svgRef.current.querySelectorAll(".node"),
        { opacity: 0, scale: 0 },
        {
          opacity: 0.6,
          scale: 1,
          duration: 0.6,
          stagger: 0.08,
          ease: "back.out(2)",
          transformOrigin: "center",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 65%",
          },
        }
      );

      gsap.fromTo(
        svgRef.current.querySelectorAll(".stray"),
        { strokeDashoffset: 1 },
        {
          strokeDashoffset: 0,
          duration: 1,
          stagger: 0.1,
          ease: "power1.inOut",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 60%",
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="problem"
      ref={sectionRef}
      className="relative py-32 sm:py-40 px-6 sm:px-10 lg:px-24"
    >
      <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
        <div ref={textRef}>
          <p className="font-mono text-[11px] tracking-widest2 text-gold uppercase mb-6">
            {problem.eyebrow}
          </p>
          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-ivory leading-tight mb-8 max-w-xl">
            {problem.headline}
          </h2>
          {problem.body.map((p, i) => (
            <p
              key={i}
              className="font-sans text-base sm:text-lg text-stone leading-relaxed max-w-lg mb-4"
            >
              {p}
            </p>
          ))}
        </div>

        <div className="flex justify-center lg:justify-end">
          <svg
            ref={svgRef}
            viewBox="0 0 360 360"
            className="w-full max-w-md opacity-90"
            aria-hidden="true"
          >
            {strays.map((s, i) => (
              <line
                key={i}
                className="stray"
                x1={s.x1}
                y1={s.y1}
                x2={s.x2}
                y2={s.y2}
                stroke="#8B847A"
                strokeWidth="1"
                strokeDasharray="1 1"
                pathLength="1"
                opacity="0.35"
              />
            ))}
            {nodes.map((n, i) => (
              <circle
                key={i}
                className="node"
                cx={n.x}
                cy={n.y}
                r="5"
                fill={i % 2 === 0 ? "#C9A05A" : "#8B847A"}
              />
            ))}
          </svg>
        </div>
      </div>
    </section>
  );
}
